// WorkBuddy Skills plugin entrypoint: skills-only, no tools or hooks.
export default {
  id: "workbuddy-skills",
  name: "WorkBuddy Skills",
  description: "All WorkBuddy user + bundled skills, converted for OpenClaw.",
  register() {},
};
