using ClawLauncher;

internal static class InstanceDeletionTests
{
 public static IReadOnlyList<(bool Ok,string Name)> Run()
 {
  var result=new List<(bool,string)>();
  var root=Path.Combine(Path.GetTempPath(),"ocl-delete-test-"+Guid.NewGuid().ToString("N"));
  try
  {
   var id=Guid.NewGuid().ToString("N");var state=Path.Combine(root,"instances",id);var other=Path.Combine(root,"instances","other");
   var workspace=Path.Combine(state,"workspace");var sessions=Path.Combine(state,"agents","main","sessions");
   var auth=Path.Combine(state,"agents","main","agent","auth-profiles.json");var credential=Path.Combine(state,"credentials","oauth.json");var plugin=Path.Combine(state,"extensions","sample-plugin","index.js");
   Directory.CreateDirectory(workspace);Directory.CreateDirectory(sessions);Directory.CreateDirectory(Path.GetDirectoryName(auth)!);Directory.CreateDirectory(Path.GetDirectoryName(credential)!);Directory.CreateDirectory(Path.GetDirectoryName(plugin)!);Directory.CreateDirectory(other);
   File.WriteAllText(Path.Combine(workspace,"notes.md"),"user note");File.WriteAllText(Path.Combine(sessions,"conversation.jsonl"),"conversation");
   File.WriteAllText(auth,"secret-marker");File.WriteAllText(credential,"oauth-secret");File.WriteAllText(plugin,"plugin");File.WriteAllText(Path.Combine(state,"openclaw.json"),"{}");File.WriteAllText(Path.Combine(other,"keep.txt"),"other instance");
   var instance=new Instance{Id=id,Managed=true,State=state,Config=Path.Combine(state,"openclaw.json")};
   var plan=InstanceDeletion.Plan(root,instance);
   var archive=InstanceDeletion.DeleteManagedState(root,instance);
   var ok=plan.SafeToDelete&&Directory.Exists(Path.Combine(archive,"workspace"))&&
    File.Exists(Path.Combine(archive,"workspace","notes.md"))&&File.Exists(Path.Combine(archive,"agents","main","sessions","conversation.jsonl"))&&
    File.Exists(Path.Combine(archive,"agents","main","agent","auth-profiles.json"))&&File.Exists(Path.Combine(archive,"credentials","oauth.json"))&&
    !Directory.Exists(state)&&
    !Directory.Exists(Path.Combine(archive,"extensions"))&&File.Exists(Path.Combine(other,"keep.txt"));
   result.Add((ok,"managed deletion preserves workspace/conversations/credentials, removes plugins/config and leaves siblings"));

   var blockedId=Guid.NewGuid().ToString("N");var blockedState=Path.Combine(root,"instances",blockedId);Directory.CreateDirectory(blockedState);
   File.WriteAllText(Path.Combine(blockedState,"unknown.bin"),"preserve");
   var blockedInstance=new Instance{Id=blockedId,Managed=true,State=blockedState,Config=Path.Combine(blockedState,"openclaw.json")};
   var blocked=InstanceDeletion.Plan(root,blockedInstance);
   var refused=false;try{InstanceDeletion.DeleteManagedState(root,blockedInstance);}catch(InvalidOperationException){refused=true;}
   result.Add((!blocked.SafeToDelete&&refused&&File.Exists(Path.Combine(blockedState,"unknown.bin")),"unclassified data blocks deletion without touching the instance"));

   var outside=new Instance{Id=Guid.NewGuid().ToString("N"),Managed=true,State=root,Config=""};
   result.Add((!InstanceDeletion.Plan(root,outside).SafeToDelete,"deletion rejects a state path outside the exact managed instance root"));
  }
  finally { try{if(Directory.Exists(root))Directory.Delete(root,true);}catch{} }
  return result;
 }
}
