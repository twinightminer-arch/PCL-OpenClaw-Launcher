using System.Diagnostics;
using System.IO;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
namespace ClawLauncher;

public sealed partial class MainWindow
{
 TextBlock? launchStage;
 Action<string> openDashboardUrl=url=>Process.Start(new ProcessStartInfo(url){UseShellExecute=true});
 internal string launchTimeline="";
 readonly List<string> launchStages=[];
 string? validatedConsoleUrl;
 internal void LaunchProgress(string message) { status.Text=message;if(launchStage!=null)launchStage.Text=message;AddLog(message); }
 void RecordStage(string name,string outcome,long elapsedMs)
 {
  var line=$"{name}：{outcome}（{elapsedMs} ms）";
  launchStages.Add(line);LaunchProgress(line);
 }
 internal void ShowLaunchReport()
 {
  var text=launchTimeline.Length>0?launchTimeline:"尚无启动记录。点击“启动实例”后，这里会显示各阶段耗时和状态。";
  MessageBox.Show(this,text,"本次启动诊断",MessageBoxButton.OK,MessageBoxImage.Information);
 }

 async Task StartGateway()
 {
  var total=Stopwatch.StartNew();prepareMs=0;launchStages.Clear();validatedConsoleUrl=null;
  AddLog("启动实例：用户显式点击启动。");
  var progress=new Window{Owner=this,Title="启动 OpenClaw",Width=550,Height=330,WindowStartupLocation=WindowStartupLocation.CenterOwner,ResizeMode=ResizeMode.NoResize};
  launchStage=Text("正在检查网关…",17,"#D9363E");
  var details=new TextBlock{Text="按顺序检查进程、TCP、HTTP 健康、控制台资源和 WebSocket。",FontSize=12,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,12)};
  var panel=new StackPanel{Margin=new Thickness(24)};panel.Children.Add(launchStage);panel.Children.Add(details);
  panel.Children.Add(new ProgressBar{IsIndeterminate=true,Height=5,Margin=new Thickness(0,8,0,15)});
  panel.Children.Add(Button("取消启动",()=>cancellation?.Cancel()));progress.Content=panel;
  bool completed=false;progress.Closing+=(_,_)=>{if(!completed)cancellation?.Cancel();};
  progress.Show();await System.Windows.Threading.Dispatcher.Yield(System.Windows.Threading.DispatcherPriority.Render);
  try
  {
   await StartGatewayCoreValidated();
   var endpoint=ConsoleEndpoint();
   var ws=await GatewayReadiness.WebSocketChallengeAsync(validatedConsoleUrl??endpoint.EffectiveUrl,8000,cancellation?.Token??default);
   RecordStage("WebSocket 握手",ws.Detail,ws.ElapsedMs);
   RecordStage("控制台 RPC", "外部浏览器的认证会话无法由启动器观察；不会伪报就绪。", 0);
   var open=Stopwatch.StartNew();await OpenDashboard(true);
   RecordStage("打开浏览器", "已向默认浏览器提交打开请求。页面运行及 RPC 就绪仍需浏览器端确认。", open.ElapsedMilliseconds);
   prepareMs=total.ElapsedMilliseconds;
   launchTimeline="总耗时："+total.Elapsed.TotalSeconds.ToString("0.000")+" 秒"+Environment.NewLine+string.Join(Environment.NewLine,launchStages);
   AddLog("启动诊断完成；浏览器加载和认证状态尚未确认。"+Environment.NewLine+launchTimeline);
   LaunchProgress("网关健康且控制台资源有效；浏览器侧 RPC 状态待确认。总耗时 "+total.Elapsed.TotalSeconds.ToString("0.0")+" 秒。");
  }
  catch(OperationCanceledException)
  {
   RecordStage("启动流程","用户取消",total.ElapsedMilliseconds);
   launchTimeline="总耗时："+total.Elapsed.TotalSeconds.ToString("0.000")+" 秒"+Environment.NewLine+string.Join(Environment.NewLine,launchStages);
   if(owned.TryGetValue(current.Id,out var child)&&!child.HasExited){child.Kill(true);await child.WaitForExitAsync();owned.Remove(current.Id);child.Dispose();}
   throw;
  }
  catch(Exception error)
  {
   RecordStage("启动流程","失败："+SafeLog.Clean(error.Message),total.ElapsedMilliseconds);
   launchTimeline="总耗时："+total.Elapsed.TotalSeconds.ToString("0.000")+" 秒"+Environment.NewLine+string.Join(Environment.NewLine,launchStages);
   throw;
  }
  finally{completed=true;launchStage=null;progress.Close();}
 }

 long prepareMs;

 async Task OpenDashboard()=>await OpenDashboard(false);
 async Task OpenDashboard(bool validated)
 {
  var endpoint=ConsoleEndpoint();
  var url=validated&&!string.IsNullOrWhiteSpace(validatedConsoleUrl)?validatedConsoleUrl:endpoint.LocalUrl?endpoint.Url:await ResolveConsoleUrl();
  if(!validated)
  {
   var health=await GatewayReadiness.HttpHealthAsync(url,2500,cancellation?.Token??default);
   if(!health.Ok)throw new Exception("网关尚未通过 HTTP /healthz 检查（"+health.Detail+"）。请点击“启动实例”后再打开控制台。");
   var page=await GatewayReadiness.ConsolePageAsync(url,10000,cancellation?.Token??default);
   if(!page.Ok)throw new Exception("控制台静态页面检查失败（"+page.Detail+"）。未将其判为启动成功。");
  }
  openDashboardUrl(url);
 }

 async Task<string> ResolveConsoleUrl()
 {
  var result=await runner.Run(current,["dashboard","--json","--no-open"],45,cancellation?.Token??default);
  var data=result.Json();
  if(!result.Ok||ReadModel.B(data,"ok")!=true)throw new Exception("OpenClaw 未返回可用控制台地址："+SafeLog.Clean(ReadModel.S(data,"reason",result.Summary)));
  var url=ReadModel.S(data,"url");
  if(!Uri.TryCreate(url,UriKind.Absolute,out var uri)||uri.Scheme is not ("http" or "https"))throw new Exception("OpenClaw 返回了无效的控制台地址。");
  return url;
 }

 internal ConsoleLauncher.ConsoleEndpoint ConsoleEndpoint()
 {
  try
  {
   var path=Runner.ConfigPath(current);
   if(File.Exists(path)&&ConsoleLauncher.FromConfig(File.ReadAllText(path),current.Port) is ConsoleLauncher.ConsoleEndpoint endpoint)return endpoint;
  }
  catch(IOException){}catch(UnauthorizedAccessException){}catch(System.Text.Json.JsonException){}
  return ConsoleLauncher.ProbeEndpoint("",current.Port);
 }
}
