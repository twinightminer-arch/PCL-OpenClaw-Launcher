; OCL 0.2.0 rebuild installer. Writes to the explicitly requested OCL install path.
[Setup]
AppId={{8E1C3A72-0F5B-4D31-9C10-0A1F2B3C4D70}
AppName=PCL OpenClaw Launcher (Rebuild)
AppVersion=0.2.0
AppVerName=PCL OpenClaw Launcher 0.2.0
AppPublisher=Twinight_Miner
AppPublisherURL=https://github.com/twinightminer-arch/PCL-OpenClaw-Launcher
DefaultDirName=E:\openclaw\OCL
UsePreviousAppDir=no
DefaultGroupName=OCL 0.2.0
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=E:\openclaw\ocl\installers\0.2.0
OutputBaseFilename=OCL-0.2.0-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile=E:\openclaw\ocl\app-v0.2.0\Assets\ocl.ico
UninstallDisplayIcon={app}\Assets\ocl.ico
CloseApplications=yes
CloseApplicationsFilter=PCL-OpenClaw-Launcher.exe
DisableWelcomePage=no

[Files]
Source: "E:\openclaw\ocl\app-v0.2.0\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{userprograms}\OCL 0.2.0"; Filename: "{app}\PCL-OpenClaw-Launcher.exe"; WorkingDir: "{app}"; IconFilename: "{app}\Assets\openclaw.ico"
