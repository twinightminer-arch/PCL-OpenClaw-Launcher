using System.Diagnostics;
namespace ClawLauncher;

public sealed partial class MainWindow
{
 async Task StartGatewayCoreValidated()
 {
  Runner.EnsureGatewayConfiguration(current);
  var endpoint=ConsoleEndpoint();
  var host=endpoint.Host;
  var port=endpoint.Port;
  var url=endpoint.LocalUrl?endpoint.Url:$"http://{host}:{port}/";
  var token=cancellation?.Token??default;
  LaunchProgress("检查现有 TCP 监听…");
  var initialTcp=await GatewayReadiness.TcpAsync(host,port,700,token);
  Process? process=null;
  if(initialTcp.Ok)
  {
   RecordStage("网关进程","检测到已有监听；复用现有进程，不启动第二个网关。",initialTcp.ElapsedMs);
  }
  else
  {
   ClearStaleGatewayLock();
   LaunchProgress("启动所选实例的网关进程…");
   var start=Stopwatch.StartNew();
   process=StartGatewayProcess();
   RecordStage("网关进程",process!=null?"Process.Start 成功。":"无法取得网关进程。",start.ElapsedMilliseconds);
   if(process==null)throw new Exception("网关进程没有启动，请查看操作日志。");
  }

  var tcp=await PollStage((ms,ct)=>GatewayReadiness.TcpAsync(host,port,ms,ct),30000,process,token);
  RecordStage("TCP 监听",tcp.Detail,tcp.ElapsedMs);
  if(!tcp.Ok)throw new Exception("TCP 监听阶段失败："+tcp.Detail+" 请检查端口占用、bind 地址及网关进程日志。");

  var health=await PollStage((ms,ct)=>GatewayReadiness.HttpHealthAsync(url,ms,ct),180000,process,token);
  RecordStage("HTTP /healthz",health.Detail,health.ElapsedMs);
  if(!health.Ok)throw new Exception("HTTP 健康检查失败："+health.Detail+" TCP 监听不能代表网关健康。");
  prepareMs=health.ElapsedMs;

  if(!endpoint.LocalUrl)url=await ResolveConsoleUrl();
  validatedConsoleUrl=url;
  var page=await GatewayReadiness.ConsolePageAsync(url,30000,token);
  RecordStage("控制台页面/静态资源",page.Detail,page.ElapsedMs);
  if(!page.Ok)throw new Exception("控制台页面检查失败："+page.Detail+" 未打开浏览器，也未将控制台判为就绪。");
  checkedAt=DateTime.Now;
 }

 static async Task<ReadinessResult> PollStage(Func<int,CancellationToken,Task<ReadinessResult>> probe,int timeoutMs,Process? process,CancellationToken cancellation)
 {
  var watch=Stopwatch.StartNew();
  while(watch.ElapsedMilliseconds<timeoutMs)
  {
   cancellation.ThrowIfCancellationRequested();
   if(process!=null)
   {
    try{if(process.HasExited)return new(false,"网关进程已退出，exit code "+process.ExitCode+"。",watch.ElapsedMilliseconds);}
    catch(InvalidOperationException){return new(false,"无法读取网关进程状态。",watch.ElapsedMilliseconds);}
   }
   var remaining=(int)Math.Max(1,timeoutMs-watch.ElapsedMilliseconds);
   var result=await probe(Math.Min(900,remaining),cancellation);
   if(result.Ok)return result with {ElapsedMs=watch.ElapsedMilliseconds};
   remaining=(int)Math.Max(0,timeoutMs-watch.ElapsedMilliseconds);
   if(remaining>0)await Task.Delay(Math.Min(180,remaining),cancellation);
  }
  return new(false,"阶段超时，上限 "+timeoutMs+" ms。",watch.ElapsedMilliseconds);
 }
}
