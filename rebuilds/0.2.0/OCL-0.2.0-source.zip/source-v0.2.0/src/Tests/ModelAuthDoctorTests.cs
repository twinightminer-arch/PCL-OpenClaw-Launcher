using ClawLauncher;

internal static class ModelAuthDoctorTests
{
 public static IReadOnlyList<(bool Ok,string Name)> Run()
 {
  var results=new List<(bool,string)>();
  var root=Path.Combine(Path.GetTempPath(),"ocl-auth-doctor-"+Guid.NewGuid().ToString("N"));
  try
  {
   var agent=Path.Combine(root,"agents","main","agent");Directory.CreateDirectory(agent);
   var instance=new Instance{Id="test",State=root,Config=Path.Combine(root,"openclaw.json")};
   var missing=ModelAuthDoctor.Inspect(instance,"deepseek","deepseek:default");
   results.Add((missing.Status=="profile 缺失"&&!missing.Detail.Contains("key=",StringComparison.OrdinalIgnoreCase),"DeepSeek profile missing is reported without changing configuration"));
   File.WriteAllText(Path.Combine(agent,"auth-profiles.json"),"""{"version":1,"profiles":{"deepseek:default":{"type":"api_key","provider":"deepseek","key":"secret-marker"}}}""");
   var present=ModelAuthDoctor.Inspect(instance,"deepseek","deepseek:default");
   results.Add((present.Status=="配置条目存在"&&!present.Detail.Contains("secret-marker"),"DeepSeek profile presence is reported without exposing credential values"));
   File.WriteAllText(Path.Combine(agent,"auth-profiles.json"),"{" );
   var malformed=ModelAuthDoctor.Inspect(instance,"deepseek","deepseek:default");
   results.Add((malformed.Status=="认证文件不可解析"&&!malformed.Detail.Contains("secret-marker"),"malformed auth store is distinguished without exposing credential values"));
  }
  finally { try { if(Directory.Exists(root))Directory.Delete(root,true); } catch(IOException) { } }
  return results;
 }
}
