$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'src\Launcher\Launcher.csproj'
$output = Join-Path (Split-Path $PSScriptRoot -Parent) 'app-v0.2.0'
dotnet restore $project --force -p:RuntimeIdentifier=
if ($LASTEXITCODE -ne 0) { throw "dotnet restore failed with exit code $LASTEXITCODE" }
dotnet build $project -c Release --no-restore `
  -p:RuntimeIdentifier= -p:UseAppHost=true -p:Version=0.2.0 -o $output
if ($LASTEXITCODE -ne 0) { throw "dotnet build failed with exit code $LASTEXITCODE" }
if (-not (Test-Path -LiteralPath (Join-Path $output 'PCL-OpenClaw-Launcher.exe'))) {
  throw 'Publish completed without the launcher executable.'
}

