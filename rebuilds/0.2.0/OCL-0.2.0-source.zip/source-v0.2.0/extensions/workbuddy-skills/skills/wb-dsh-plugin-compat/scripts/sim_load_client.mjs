/**
 * 模拟 DSH Desktop 渲染端 shell，加载插件 client.js 并实跑 factory()
 *
 * 检查两件事：
 *   (a) factory 请求的模块是否都在平台模块表内（否则报 "missed the module table"）
 *   (b) factory 本身是否抛错
 *
 * 用法：
 *   node sim_load_client.mjs <client.js 路径> [<client.js 路径> ...]
 *   node sim_load_client.mjs --app "<app 目录>" <client.js ...>
 *
 * app 目录用于推断平台模块白名单（读 package.json 的 dependencies）。
 */
import { readFileSync } from 'node:fs'
import { runInNewContext } from 'node:vm'
import { resolve, dirname } from 'node:path'

const argv = process.argv.slice(2)
let appDir = 'E:/DeepSeekHarness/DSH Desktop/resources/app'
const files = []
for (let i = 0; i < argv.length; i++) {
  if (argv[i] === '--app') { appDir = argv[++i]; continue }
  files.push(argv[i])
}
if (files.length === 0) {
  console.log('用法: node sim_load_client.mjs [--app <app目录>] <client.js> [...]')
  process.exit(2)
}

// ---- 平台模块白名单 ----
let whitelist = new Set(['react', 'react/jsx-runtime'])
try {
  const pj = JSON.parse(readFileSync(resolve(appDir, 'package.json'), 'utf8'))
  for (const k of Object.keys(pj.dependencies || {})) {
    if (k.startsWith('@deepseek-ai/')) whitelist.add(k)
  }
  console.log(`[info] 平台模块白名单 ${whitelist.size} 项（来自 ${appDir}/package.json）`)
} catch (e) {
  console.log('[warn] 无法读取 app/package.json，仅用内置白名单:', e.message)
}

// ---- 尝试载入真实 store 模块（可选） ----
let realStore = null
try {
  const url = 'file:///' + resolve(appDir, 'node_modules/@deepseek-ai/dsh-client-store/lib/index.js')
    .replace(/\\/g, '/').replace(/ /g, '%20')
  realStore = await import(url)
  console.log('[info] 真实 dsh-client-store 已载入')
} catch (e) {
  realStore = {
    createSnapshotStore: (init) => ({ getSnapshot: () => init, subscribe: () => () => {}, update() {}, set() {} }),
    defineStore: (d) => ({ spec: d, create: () => ({ actions: {}, getSnapshot: () => d.init(), subscribe: () => () => {} }) }),
  }
  console.log('[info] 真实 store 不可用（缺 zustand 等），改用同形 stub')
}

const mkEl = () => ({
  style: {}, dataset: {}, classList: { add() {}, remove() {}, contains: () => false },
  setAttribute() {}, getAttribute: () => null, removeAttribute() {},
  appendChild: () => null, insertBefore() {}, removeChild() {}, remove() {},
  addEventListener() {}, removeEventListener() {},
  querySelector: () => null, querySelectorAll: () => [], closest: () => null,
  contains: () => false, cloneNode: () => mkEl(),
  getBoundingClientRect: () => ({ top: 0, left: 0, width: 0, height: 0 }),
})

function makeSandbox(regs) {
  const doc = {
    querySelector: () => null, querySelectorAll: () => [], getElementById: () => null,
    createElement: () => mkEl(), createTextNode: () => ({}), createDocumentFragment: () => mkEl(),
    addEventListener() {}, removeEventListener() {}, readyState: 'complete',
    head: mkEl(), body: mkEl(), documentElement: mkEl(), title: '',
  }
  return {
    window: { __ModuleLoader__: { load: (r) => regs.push(r) } },
    document: doc,
    console,
    setTimeout, clearTimeout, setInterval, clearInterval,
    requestAnimationFrame: (f) => setTimeout(f, 0), cancelAnimationFrame: () => {},
    MutationObserver: class { observe() {} disconnect() {} takeRecords() { return [] } },
    NodeFilter: { SHOW_TEXT: 4, SHOW_ELEMENT: 1, FILTER_ACCEPT: 1, FILTER_REJECT: 2 },
    localStorage: undefined,
  }
}

function stubFor(spec) {
  if (spec === '@deepseek-ai/dsh-client-store') return realStore
  if (spec === 'react') {
    return {
      useState: (v) => [typeof v === 'function' ? v() : v, () => {}],
      useEffect: () => {}, useMemo: (f) => f(), useRef: (v) => ({ current: v }),
      useCallback: (f) => f, createElement: () => null, Fragment: Symbol('Fragment'),
      createContext: () => ({ Provider: () => null }), useContext: () => ({}),
    }
  }
  if (spec === 'react/jsx-runtime') return { jsx: () => null, jsxs: () => null, Fragment: Symbol('Fragment') }
  return new Proxy({}, { get: () => () => null })   // 其他平台模块给宽松 stub
}

let fail = 0
for (const P of files) {
  const short = P.split(/[\\/]/).slice(-3, -2)[0] || P
  console.log('\n================ ' + short + ' ================')
  const regs = []
  try {
    runInNewContext(readFileSync(P, 'utf8'), makeSandbox(regs), { filename: P })
  } catch (e) {
    console.log('  [注册阶段异常] ' + e.message); fail++; continue
  }
  const reg = regs[0]
  if (!reg) { console.log('  !! 未注册任何模块'); fail++; continue }
  console.log('  id: ' + reg.id)

  const requested = new Set()
  let mod = null, err = null
  try {
    mod = reg.factory((spec) => { requested.add(spec); return stubFor(spec) })
  } catch (e) { err = e }

  const reqList = [...requested]
  const bad = reqList.filter((s) => !whitelist.has(s) && !s.startsWith('react'))
  console.log('  requires      : ' + JSON.stringify(reqList))
  console.log('  非白名单依赖  : ' + (bad.length === 0 ? 'NONE' : JSON.stringify(bad)))
  console.log('  factory 异常  : ' + (err === null ? 'NONE (PASS)' : String((err && err.message) || err)))
  if (mod) {
    console.log('  exports       : ' + Object.keys(mod).join(', '))
    if (mod.inject) console.log('  inject        : ' + JSON.stringify(mod.inject))
  }
  if (err || bad.length) fail++
}
console.log('\n==== 汇总: %d 个文件, %d 个有问题 ====', files.length, fail)
process.exit(fail ? 1 : 0)
