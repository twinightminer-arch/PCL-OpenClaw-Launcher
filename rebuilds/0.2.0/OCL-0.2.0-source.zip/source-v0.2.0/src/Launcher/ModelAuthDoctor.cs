using System.Text.Json.Nodes;
using System.IO;

namespace ClawLauncher;

public sealed record ModelAuthDiagnosis(string Status,string Detail,string AgentDirectory,string ProfileId);

/// <summary>Read-only, secret-safe local inspection of one OpenClaw model auth profile.</summary>
public static class ModelAuthDoctor
{
 public static ModelAuthDiagnosis Inspect(Instance instance,string provider,string profileId)
 {
  var root=RuntimeDoctor.StateDirectory(instance);
  var agents=Path.Combine(root,"agents");
  if(!Directory.Exists(agents))return Missing("此状态目录没有 agents 认证目录；没有读取或修改其他实例。",Path.Combine(agents,"main","agent"));

  var matchingProviders=new List<string>();var unreadable=new List<string>();
  IEnumerable<string> agentDirs;
  try { agentDirs=Directory.GetDirectories(agents).Where(d=>(File.GetAttributes(d)&FileAttributes.ReparsePoint)==0).ToArray(); }
  catch(Exception e) when(e is IOException or UnauthorizedAccessException) { return new("无法读取", "无法读取当前实例的 agents 目录："+e.Message,agents,profileId); }

  foreach(var idDir in agentDirs)
  {
   var agentDir=Path.Combine(idDir,"agent");
   if(!Directory.Exists(agentDir))continue;
   foreach(var filename in new[]{"auth-profiles.json","auth.json"})
   {
    var file=Path.Combine(agentDir,filename);if(!File.Exists(file))continue;
    JsonNode? parsed;
    try { parsed=JsonNode.Parse(File.ReadAllText(file)); }
    catch(Exception e) when(e is IOException or UnauthorizedAccessException or System.Text.Json.JsonException) { unreadable.Add(file);continue; }
    var profiles=parsed?["profiles"] as JsonObject ?? (filename=="auth.json"?parsed as JsonObject:null);
    if(profiles==null) { unreadable.Add(file);continue; }
    if(profiles[profileId] is JsonNode exact)
    {
     var actualProvider=exact["provider"]?.ToString();
     if(!string.Equals(actualProvider,provider,StringComparison.OrdinalIgnoreCase))
      return new("provider 不匹配",$"文件中存在 {profileId}，但 provider 字段不匹配；认证值未输出。",agentDir,profileId);
     var hasCredential=new[]{"key","keyRef","token","tokenRef","access","refresh"}.Any(k=>!string.IsNullOrWhiteSpace(exact[k]?.ToString()));
     return hasCredential
      ?new("配置条目存在","本地 profile 含凭据字段；尚未验证密钥解析、服务端认证或模型请求。",agentDir,profileId)
      :new("凭据字段缺失","profile 条目存在，但没有可识别的密钥或密钥引用字段；认证值未输出。",agentDir,profileId);
    }
    foreach(var pair in profiles)
     if(string.Equals(pair.Value?["provider"]?.ToString(),provider,StringComparison.OrdinalIgnoreCase))matchingProviders.Add(pair.Key);
   }
  }
  if(unreadable.Count>0)return new("认证文件不可解析","未找到目标 profile；存在无法解析的认证文件："+string.Join("；",unreadable),Path.GetDirectoryName(unreadable[0])!,profileId);
  if(matchingProviders.Count>0)return new("指定 profile 缺失",$"未找到 {profileId}；当前实例发现同一 provider 的 profile："+string.Join("、",matchingProviders.Distinct(StringComparer.OrdinalIgnoreCase))+"。",agents,profileId);
  return Missing($"当前实例未找到 {profileId}。环境变量或外部密钥提供器没有在此只读检查中解析。",Path.Combine(agents,"main","agent"));

  ModelAuthDiagnosis Missing(string detail,string agentDir)=>new("profile 缺失",detail,agentDir,profileId);
 }

 public static string ConfiguredModel(Instance instance)
 {
  try
  {
   var config=JsonNode.Parse(File.ReadAllText(Runner.ConfigPath(instance)));
   var model=config?["agents"]?["defaults"]?["model"];
   return model is JsonObject ? model["primary"]?.ToString()??"未配置" : model?.ToString()??"未配置";
  }
  catch { return "配置不存在或无法解析"; }
 }
}
