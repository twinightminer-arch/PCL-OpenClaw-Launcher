---
name: wb-word-template-fill
description: "把内容填进 Word 模板（.doc/.docx）——复制空白模板、往表格单元格或指定段落填入内容、保留原版式（页边框/抬头/字体/黑体小标题），最后输出 .doc/.docx 并导 PDF 核对。当用户说「把这个模板复制几份，把 XX 内容填进去」「按这个表格式模板生成报告/表单」「空白模板 + 若干份不同内容」时使用。核心是靠本机 Microsoft Office 的 Word COM 做 doc↔docx↔pdf 转换，用 python-docx 精确填充。"
user-invocable: true
metadata: { "openclaw": { "emoji": "📄", "origin": "workbuddy-user" } }
---

# word-template-fill

> 由 WorkBuddy 技能 `word-template-fill` 转换而来，供 OpenClaw 使用。

# Word 模板填充（word-template-fill）

## 适用场景
- 有 1 个空白模板（.doc 或 .docx），要生成 N 份、每份填入不同内容。
- 模板通常是「抬头段落 + 单列表格（每行一个栏目）」，或一系列标题段落。
- 用户要求尽量保持模板原版式（边框、字体、页码、栏目结构）。

## 前置：本机能力（Windows）
- **Word COM 可用**（本机装 Microsoft Office Office16：`C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE`）。
  PowerShell 里 `Add-Type` / `Reflection.Assembly` 加载**会被沙箱拦截**，但 `New-Object -ComObject Word.Application` 可用。
- 无 libreoffice / pandoc；`.doc` 旧二进制格式**只能**靠 Word COM 转成 .docx 后再用 python-docx 处理。
- Python：受管 venv `C:\Users\<user>\.workbuddy\binaries\python\envs\default\Scripts\python.exe`
  （Windows 是 `Scripts/` 不是 `bin/`）。按需 `pip install olefile python-docx pymupdf`。

## 标准流程
1. **拿到源文件**：模板 + 各份内容源，下载到工作目录。
2. **探明模板结构**
   - 若是 `.doc`：先 Word COM 转 docx（`SaveAs2(path, 16)`），再用 python-docx 读段落/表格/字体/行高。
   - `.doc` 纯文本应急读取：`olefile` 开 `WordDocument` 流，按 `utf-16-le` 解码后用正则抓 CJK 串（能拿到栏目名）。
3. **定位填写点**：查 `doc.paragraphs`（抬头字段）与 `doc.tables`（栏目行）。表格单元格里 `cell.paragraphs[0]` 一般是该栏目标题。
4. **填充（python-docx）**
   - 保留单元格首段（标题），删除其余空段：`for p in list(cell.paragraphs[1:]): p._p.getparent().remove(p._p)`。
   - 用 `OxmlElement("w:p")` + `para._p.addnext(new_p)` 在标题后**依次**插入内容段，游标逐段后移。
   - 统一设置字体：`w:ascii/hAnsi=Times New Roman`、`w:eastAsia=宋体`、`size=Pt(12)`、`color=RGBColor(0,0,0)`；小标题 `bold=True`。
   - 若表格行设了固定高，把要随内容增高的行改 `row.height_rule = WD_ROW_HEIGHT_RULE.AT_LEAST`（否则可能裁剪）。
5. **输出 .doc**：Word COM `SaveAs2(out, 0)`（wdFormatDocument97）。
6. **核对**：Word COM `ExportAsFixedFormat(pdf, 17)` 导 PDF → PyMuPDF `page.get_pixmap(dpi=110)` 渲 PNG → 用 Read 看图核对版式。
7. **清理**：`$word.Quit()` 后仍常残留 `WINWORD.EXE`，`taskkill /F /IM WINWORD.EXE`。
8. **交付**：把成品复制到真实桌面 `C:\Users\李忠浩\OneDrive\Desktop(1)`，`present_files` 展示。

## 关键代码片段
```python
from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph
from docx.enum.text import WD_ALIGN_PARAGRAPH

def insert_para_after(paragraph, text, bold=False, size=12.0):
    new_p = OxmlElement("w:p")
    paragraph._p.addnext(new_p)
    para = Paragraph(new_p, paragraph._parent)
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT
    para.paragraph_format.line_spacing = 1.25
    if text:
        r = para.add_run(text); r.font.size = Pt(size); r.font.bold = bold
        r.font.name = "Times New Roman"
        rf = r._element.get_or_add_rPr().get_or_add_rFonts()
        rf.set(qn("w:ascii"), "Times New Roman"); rf.set(qn("w:hAnsi"), "Times New Roman")
        rf.set(qn("w:eastAsia"), "宋体")
    return para

def fill_cell(cell, lines):           # lines: [(text, bold), ...]
    for p in list(cell.paragraphs[1:]):
        p._p.getparent().remove(p._p)
    cur = cell.paragraphs[0]
    for text, bold in lines:
        cur = insert_para_after(cur, text, bold)
```

Word COM（PowerShell，一次跑多份）：
```powershell
$w = New-Object -ComObject Word.Application; $w.Visible=$false; $w.DisplayAlerts=0
$d = $w.Documents.Open($docxPath, $false, $false)
$d.SaveAs2($docPath, 0)            # .doc
$d.ExportAsFixedFormat($pdfPath, 17)   # PDF
$d.Close($false); $w.Quit()
```
（`taskkill /F /IM WINWORD.EXE` 收尾。）

## 坑
- **公式/示意图**：教材里的离子方程式常是 `Equation.3` OLE 对象（WMF），python-docx 读不到文本，`<w:object>` 也不出文本。Pillow 渲 WMF 会字符重叠错位，`Add-Type`+System.Drawing 被拦。务实做法：按上下文用规范化学式文本还原（`SO₄²⁻`、`Ba²⁺`、`mol·L⁻¹` 等 Unicode 上下标），并把因图片丢失而空缺的离子按上下文补回。
- `.doc` 里的文字若用 UTF-16 抽不到，说明该段是 1 字节压缩片，只能靠 Word COM 转 docx 再读。
- 表格 `trHeight` 无 `hRule` 时默认按内容自适应；显式设 `AT_LEAST` 最稳。
- 用户的输出偏好：真实桌面 `C:\Users\李忠浩\OneDrive\Desktop(1)`；成品一般要 .doc 与模板同格式。
- 交付前**务必**导 PDF 渲图目视核对，不要只信 XML。
