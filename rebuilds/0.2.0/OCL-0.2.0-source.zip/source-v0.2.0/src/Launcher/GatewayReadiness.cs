using System.Net;
using System.Net.Http;
using System.Net.WebSockets;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace ClawLauncher;

internal sealed record ReadinessResult(bool Ok, string Detail, long ElapsedMs);

internal static class GatewayReadiness
{
 private static readonly HttpClient Http = new(new SocketsHttpHandler
 {
  UseProxy = false,
  AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate | DecompressionMethods.Brotli,
  PooledConnectionLifetime = TimeSpan.FromMinutes(2)
 }) { Timeout = Timeout.InfiniteTimeSpan };

 public static async Task<ReadinessResult> TcpAsync(string host, int port, int timeoutMs, CancellationToken cancellation)
 {
  var watch = System.Diagnostics.Stopwatch.StartNew();
  try
  {
   using var budget = CancellationTokenSource.CreateLinkedTokenSource(cancellation);
   budget.CancelAfter(Math.Max(1, timeoutMs));
   using var socket = new System.Net.Sockets.TcpClient();
   await socket.ConnectAsync(host, port, budget.Token).ConfigureAwait(false);
   return new(true, "TCP 连接成功。", watch.ElapsedMilliseconds);
  }
  catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { throw; }
  catch (Exception ex) when (ex is OperationCanceledException or System.Net.Sockets.SocketException or ArgumentException)
  {
   return new(false, ex is OperationCanceledException ? "TCP 连接超时。" : "TCP 端口尚未接受连接。", watch.ElapsedMilliseconds);
  }
 }

 public static async Task<ReadinessResult> HttpHealthAsync(string consoleUrl, int timeoutMs, CancellationToken cancellation)
 {
  var watch = System.Diagnostics.Stopwatch.StartNew();
  if (!TryUri(consoleUrl, out var page)) return new(false, "控制台地址无效，无法检查 /healthz。", 0);
  var health = new UriBuilder(page) { Path = "/healthz", Query = "", Fragment = "" }.Uri;
  try
  {
   using var budget = CancellationTokenSource.CreateLinkedTokenSource(cancellation);
   budget.CancelAfter(Math.Max(1, timeoutMs));
   using var request = new HttpRequestMessage(HttpMethod.Get, health);
   request.Headers.CacheControl = new() { NoCache = true };
   using var response = await Http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, budget.Token).ConfigureAwait(false);
   return response.IsSuccessStatusCode
    ? new(true, "HTTP /healthz 返回 " + (int)response.StatusCode + "。", watch.ElapsedMilliseconds)
    : new(false, "HTTP /healthz 返回 " + (int)response.StatusCode + "。", watch.ElapsedMilliseconds);
  }
  catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { throw; }
  catch (OperationCanceledException) { return new(false, "HTTP /healthz 请求超时。", watch.ElapsedMilliseconds); }
  catch (HttpRequestException ex) { return new(false, "HTTP /healthz 请求失败：" + ex.GetType().Name + "。", watch.ElapsedMilliseconds); }
 }

 public static async Task<ReadinessResult> ConsolePageAsync(string consoleUrl, int timeoutMs, CancellationToken cancellation)
 {
  var watch = System.Diagnostics.Stopwatch.StartNew();
  if (!TryUri(consoleUrl, out var page)) return new(false, "控制台 URL 无效。", 0);
  try
  {
   using var budget = CancellationTokenSource.CreateLinkedTokenSource(cancellation);
   budget.CancelAfter(Math.Max(1, timeoutMs));
   using var request = new HttpRequestMessage(HttpMethod.Get, WithoutFragment(page));
   request.Headers.CacheControl = new() { NoCache = true };
   request.Headers.Pragma.ParseAdd("no-cache");
   using var response = await Http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, budget.Token).ConfigureAwait(false);
   if (!response.IsSuccessStatusCode) return new(false, "控制台页面返回 HTTP " + (int)response.StatusCode + "。", watch.ElapsedMilliseconds);
   if (response.Content.Headers.ContentType?.MediaType?.Equals("text/html", StringComparison.OrdinalIgnoreCase) != true)
    return new(false, "控制台地址未返回 HTML 页面。", watch.ElapsedMilliseconds);
   var html = await response.Content.ReadAsStringAsync(budget.Token).ConfigureAwait(false);
   if (string.IsNullOrWhiteSpace(html)) return new(false, "控制台 HTML 内容为空。", watch.ElapsedMilliseconds);

   var assets = ExtractLocalAssets(html, page).Distinct().ToArray();
   if (assets.Length > 24) return new(false, "控制台静态资源数量超过检查上限；页面未判为就绪。", watch.ElapsedMilliseconds);
   foreach (var asset in assets)
   {
    using var assetRequest = new HttpRequestMessage(HttpMethod.Get, asset);
    assetRequest.Headers.CacheControl = new() { NoCache = true };
    using var assetResponse = await Http.SendAsync(assetRequest, HttpCompletionOption.ResponseHeadersRead, budget.Token).ConfigureAwait(false);
    if (!assetResponse.IsSuccessStatusCode)
     return new(false, "控制台静态资源返回 HTTP " + (int)assetResponse.StatusCode + "。", watch.ElapsedMilliseconds);
   }
   return new(true, "HTML 页面有效；检查了 " + assets.Length + " 个同源脚本/样式资源。", watch.ElapsedMilliseconds);
  }
  catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { throw; }
  catch (OperationCanceledException) { return new(false, "控制台页面或静态资源加载超时。", watch.ElapsedMilliseconds); }
  catch (HttpRequestException ex) { return new(false, "控制台静态资源请求失败：" + ex.GetType().Name + "。", watch.ElapsedMilliseconds); }
 }

 public static async Task<ReadinessResult> WebSocketChallengeAsync(string consoleUrl, int timeoutMs, CancellationToken cancellation)
 {
  var watch = System.Diagnostics.Stopwatch.StartNew();
  if (!TryUri(consoleUrl, out var page)) return new(false, "控制台 URL 无效，无法检查 WebSocket。", 0);
  var ws = new UriBuilder(page) { Scheme = page.Scheme == "https" ? "wss" : "ws", Fragment = "" }.Uri;
  try
  {
   using var budget = CancellationTokenSource.CreateLinkedTokenSource(cancellation);
   budget.CancelAfter(Math.Max(1, timeoutMs));
   using var socket = new ClientWebSocket();
   await socket.ConnectAsync(ws, budget.Token).ConfigureAwait(false);
   var buffer = new byte[4096];
   using var message = new MemoryStream();
   WebSocketReceiveResult result;
   do
   {
    result = await socket.ReceiveAsync(buffer, budget.Token).ConfigureAwait(false);
    if (result.MessageType == WebSocketMessageType.Close) return new(false, "网关关闭了 WebSocket 握手。", watch.ElapsedMilliseconds);
    if (message.Length + result.Count > 16384) return new(false, "WebSocket 握手响应过大。", watch.ElapsedMilliseconds);
    message.Write(buffer, 0, result.Count);
   } while (!result.EndOfMessage);
   using var json = JsonDocument.Parse(Encoding.UTF8.GetString(message.ToArray()));
   var root = json.RootElement;
   var challenge = root.TryGetProperty("event", out var name) && name.GetString() == "connect.challenge";
   return challenge
    ? new(true, "收到网关 connect.challenge；浏览器仍需完成身份验证与 RPC 会话。", watch.ElapsedMilliseconds)
    : new(false, "WebSocket 已连接，但未收到预期的 connect.challenge。", watch.ElapsedMilliseconds);
  }
  catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { throw; }
  catch (OperationCanceledException) { return new(false, "WebSocket 握手超时。", watch.ElapsedMilliseconds); }
  catch (Exception ex) when (ex is WebSocketException or HttpRequestException or JsonException or UriFormatException)
  {
   return new(false, "WebSocket 握手失败：" + ex.GetType().Name + "。", watch.ElapsedMilliseconds);
  }
 }

 private static bool TryUri(string value, out Uri uri)
 {
  var safe = (value ?? "").Trim();
  var fragment = safe.IndexOf('#');
  if (fragment >= 0) safe = safe[..fragment];
  return Uri.TryCreate(safe, UriKind.Absolute, out uri!) && uri.Scheme is "http" or "https";
 }

 private static Uri WithoutFragment(Uri uri) => new UriBuilder(uri) { Fragment = "" }.Uri;

 private static IEnumerable<Uri> ExtractLocalAssets(string html, Uri page)
 {
  foreach (Match tagMatch in Regex.Matches(html, @"<(script|link)\b[^>]*>", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant))
  {
   var tag = tagMatch.Value;
   var isScript = tagMatch.Groups[1].Value.Equals("script", StringComparison.OrdinalIgnoreCase);
   if (!isScript && !Regex.IsMatch(tag, @"\brel\s*=\s*[""'][^""']*stylesheet", RegexOptions.IgnoreCase)) continue;
   var attribute = isScript ? "src" : "href";
   var value = Regex.Match(tag, @"\b" + attribute + @"\s*=\s*[""']([^""']+)[""']", RegexOptions.IgnoreCase);
   if (!value.Success || !Uri.TryCreate(page, WebUtility.HtmlDecode(value.Groups[1].Value), out var asset)) continue;
   if (asset.Scheme == page.Scheme && asset.Host.Equals(page.Host, StringComparison.OrdinalIgnoreCase) && asset.Port == page.Port)
    yield return WithoutFragment(asset);
  }
 }
}
