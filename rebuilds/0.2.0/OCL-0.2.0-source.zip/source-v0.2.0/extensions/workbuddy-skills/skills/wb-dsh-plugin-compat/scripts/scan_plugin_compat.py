#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DSH Desktop 插件兼容性扫描（三类问题一次扫完）

  1) require 了 app 模块表里不存在的模块（会报 "missed the module table"）
  2) inject 里声明了 app 从未 provide 的服务（fiber 永久 pending，报错无 message）
  3) ctx.<prop> 属性访问了平台服务但没声明 inject（会报 "without inject"）

用法：
  python scan_plugin_compat.py [--profile <dir>] [--app <dir>] [--out report.md]

默认自动定位 %USERPROFILE%\\.dsh\\profiles\\desktop 与常见 DSH 安装目录。
"""
import os, re, io, sys, json, argparse

# ---------- 定位路径 ----------
def find_profile():
    base = os.path.join(os.path.expanduser("~"), ".dsh", "profiles")
    if not os.path.isdir(base):
        return None
    subs = [d for d in sorted(os.listdir(base)) if os.path.isdir(os.path.join(base, d))]
    for pref in ("desktop", "default"):
        if pref in subs:
            return os.path.join(base, pref)
    return os.path.join(base, subs[0]) if subs else None

def find_app():
    cands = []
    for drive in ("C:", "D:", "E:", "F:"):
        for root in ("DeepSeekHarness", "Program Files", "Program Files (x86)",
                     os.path.join("Users", os.path.basename(os.path.expanduser("~")))):
            cands.append(os.path.join(drive + os.sep, root, "DSH Desktop", "resources", "app"))
    cands.append(os.path.join(os.path.expanduser("~"), "AppData", "Local", "Programs",
                              "DSH Desktop", "resources", "app"))
    for c in cands:
        if os.path.isdir(os.path.join(c, "node_modules", "@deepseek-ai")):
            return c
    return None

# ---------- 收集平台信息 ----------
PROVIDE_PATTERNS = [
    re.compile(r'provide\(\s*["\']([A-Za-z_$][\w.$-]*)["\']'),
    re.compile(r'super\(\s*(?:ctx|this\.ctx|\w+)\s*,\s*["\']([A-Za-z_$][\w.$-]*)["\']'),
    re.compile(r'\bnew\s+Service[^(]*\(\s*(?:ctx|this\.ctx|\w+)\s*,\s*["\']([A-Za-z_$][\w.$-]*)["\']'),
]
REQ = re.compile(r'require\(\s*["\']([^"\']+)["\']\s*\)')
INJ_PAT = re.compile(r'(?:const|let|var)\s+inject\s*=\s*\[([^\]]*)\]')
PROP_PAT = re.compile(r'(?<![.\w$])ctx\.([A-Za-z_$][\w$]*)')
PROP_PAT2 = re.compile(r'this\.ctx\.([A-Za-z_$][\w$]*)')

SEEDS = {"react", "react/jsx-runtime", "react-dom", "react-dom/client"}
CTX_METHODS = set("""on off once emit parallel bail series waterfall effect inject get set provide accessor
reflect is logger scope isolate extend plugin start stop dispose schema state root ctx config name
Symbol toString constructor apply call bind prototype __proto__ then catch finally toJSON valueOf""".split())

def walk_js(root, skip=(".git",)):
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in skip]
        for fn in fns:
            if fn.endswith((".js", ".mjs", ".cjs", ".ts")):
                yield os.path.join(dp, fn)

def platform_modules(app):
    pj = os.path.join(app, "package.json")
    mods = set()
    if os.path.exists(pj):
        try:
            d = json.load(io.open(pj, "r", encoding="utf-8"))
            for k in (d.get("dependencies") or {}):
                if k.startswith("@deepseek-ai/"):
                    mods.add(k)
        except Exception:
            pass
    return mods

def collect_provided(app, profile):
    provided = set()
    for base in (os.path.join(app, "node_modules", "@deepseek-ai"),
                 os.path.join(app, "lib"),
                 os.path.join(profile, "node_modules")):
        if not os.path.isdir(base):
            continue
        for f in walk_js(base):
            try:
                src = io.open(f, "r", encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            for pat in PROVIDE_PATTERNS:
                for m in pat.findall(src):
                    provided.add(m)
    return provided

def client_entry(pkgdir):
    pj = os.path.join(pkgdir, "package.json")
    cands = []
    if os.path.exists(pj):
        try:
            d = json.load(io.open(pj, "r", encoding="utf-8"))
            exp = d.get("exports") or {}
            if isinstance(exp, dict):
                for k in ("./client", "./client.js"):
                    v = exp.get(k)
                    if isinstance(v, str):
                        cands.append(v.lstrip("./"))
            dsh = d.get("dsh") or {}
            if isinstance(dsh.get("client"), str):
                cands.append(dsh["client"].lstrip("./"))
        except Exception:
            pass
    cands += ["lib/client.js", "client/client.js", "dist/client.js", "client.js"]
    for c in cands:
        p = os.path.join(pkgdir, c)
        if os.path.exists(p):
            return p
    return None

def enabled_plugins(profile):
    """读 profile/package.json 的 dsh.profile.bundles"""
    pj = os.path.join(profile, "package.json")
    try:
        d = json.load(io.open(pj, "r", encoding="utf-8"))
        return set((d.get("dsh") or {}).get("profile", {}).get("bundles", []) or [])
    except Exception:
        return set()

def iter_pkgs(root):
    if not os.path.isdir(root):
        return
    for name in sorted(os.listdir(root)):
        if name.startswith('.'):
            continue
        p = os.path.join(root, name)
        if not os.path.isdir(p):
            continue
        if name.startswith('@'):
            for sub in sorted(os.listdir(p)):
                sp = os.path.join(p, sub)
                if os.path.isdir(sp):
                    yield name + '/' + sub, sp
        else:
            yield name, p

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default=None)
    ap.add_argument("--app", default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    profile = a.profile or find_profile()
    app = a.app or find_app()
    if not profile or not app:
        print("!! 无法定位 profile 或 app 目录，请用 --profile / --app 指定")
        sys.exit(2)

    L = []
    L.append("profile : %s" % profile)
    L.append("app     : %s" % app)

    plat = platform_modules(app)
    provided = collect_provided(app, profile)
    enabled = enabled_plugins(profile)
    L.append("平台模块(%d) / 服务提供点(%d) / 启用插件(%d)" % (len(plat), len(provided), len(enabled)))
    L.append("")

    rows = []
    for name, pdir in iter_pkgs(os.path.join(profile, "node_modules")):
        cf = client_entry(pdir)
        if not cf or not os.path.exists(cf):
            continue
        src = io.open(cf, "r", encoding="utf-8", errors="replace").read()

        # 1) require 白名单
        reqs = sorted(set(REQ.findall(src)))
        bad_req = []
        for r in reqs:
            if r in SEEDS:
                continue
            if r.startswith("@deepseek-ai/"):
                if r not in plat:
                    bad_req.append(r)
            else:
                bad_req.append(r + "  (非 @deepseek-ai 非 seed)")

        # 2) inject 幽灵服务
        inj = []
        for blk in INJ_PAT.findall(src):
            for it in blk.split(","):
                it = it.strip().strip('"').strip("'").strip()
                if it:
                    inj.append(it)
        ghost_inj = [i for i in inj if i not in provided and "." not in i]

        # 3) ctx 属性访问未声明（且是平台服务 -> 会抛）
        props = set(PROP_PAT.findall(src)) | set(PROP_PAT2.findall(src))
        bad_prop = sorted(p for p in props
                          if p not in CTX_METHODS and p not in inj and p in provided)

        if bad_req or ghost_inj or bad_prop:
            rows.append((name, name in enabled, bad_req, ghost_inj, bad_prop))

    L.append("=" * 72)
    L.append("问题插件（%d）" % len(rows))
    L.append("=" * 72)
    for name, en, br, gi, bp in rows:
        L.append("")
        L.append(">>> %s   %s" % (name, "[已启用]" if en else "[未启用，可忽略]"))
        if br:
            L.append("    [1] require 不在模块表: %s" % br)
            L.append("        -> 换成 app/package.json dependencies 里的等价包（如")
            L.append("           @deepseek-ai/dsh-client-runtime/client => @deepseek-ai/dsh-client-store）")
        if gi:
            L.append("    [2] inject 声明了平台未提供的服务: %s" % gi)
            L.append("        -> 从 inject 移除 + ctx.get() 包 try/catch 降级（勿反向补 inject）")
        if bp:
            L.append("    [3] ctx.<prop> 属性访问但未声明 inject: %s" % bp)
            L.append("        -> 弱信号，需人工确认：属性访问只在「该服务在其 ctx 树中不可用」时才抛错；")
            L.append("           若祖先已提供该服务则完全无害（很多老插件就是这么写的，一直正常）。")
            L.append("           仅当确认服务不可用时，才补 inject 或改 ctx.get()+try/catch。")

    L.append("")
    L.append("提示：改完后用 scripts/sim_load_client.mjs 模拟加载验证，再让用户彻底重启 DSH。")

    text = "\n".join(L)
    if a.out:
        io.open(a.out, "w", encoding="utf-8").write(text)
        print("written: %s" % a.out)
    else:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        print(text)

if __name__ == "__main__":
    main()
