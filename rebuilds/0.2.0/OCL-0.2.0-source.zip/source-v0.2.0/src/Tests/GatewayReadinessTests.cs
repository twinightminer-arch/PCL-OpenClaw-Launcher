using System.Net;
using System.Net.Sockets;
using System.Text;
using ClawLauncher;

internal static class GatewayReadinessTests
{
 public static async Task<IReadOnlyList<(bool Ok,string Name)>> RunAsync()
 {
  var results=new List<(bool,string)>();
  var tcpOnly=new TcpListener(IPAddress.Loopback,0);tcpOnly.Start();
  var port=((IPEndPoint)tcpOnly.LocalEndpoint).Port;
  var attempt=GatewayReadiness.TcpAsync("127.0.0.1",port,1000,default);
  using var accepted=await tcpOnly.AcceptTcpClientAsync().WaitAsync(TimeSpan.FromSeconds(2));
  var tcp=await attempt;
  var health=await GatewayReadiness.HttpHealthAsync($"http://127.0.0.1:{port}/",120,default);
  var strictReady=await ConsoleLauncher.ReadyAsync("127.0.0.1",port,150,default);
  results.Add((tcp.Ok&&!health.Ok&&!strictReady,"TCP listening without HTTP response is not readiness"));
  tcpOnly.Stop();

  await using(var valid=new MockGateway(false))
  {
   var endpoint=$"http://127.0.0.1:{valid.Port}/";
   var ok=await GatewayReadiness.HttpHealthAsync(endpoint,1000,default);
   var page=await GatewayReadiness.ConsolePageAsync(endpoint,2000,default);
   results.Add((ok.Ok&&page.Ok,"health and all same-origin console assets respond successfully"));
  }
  await using(var missingAsset=new MockGateway(true))
  {
   var page=await GatewayReadiness.ConsolePageAsync($"http://127.0.0.1:{missingAsset.Port}/",2000,default);
   results.Add((!page.Ok&&page.Detail.Contains("静态资源"),"missing console asset fails the console-page stage"));
  }
  return results;
 }

 sealed class MockGateway : IAsyncDisposable
 {
  readonly TcpListener listener=new(IPAddress.Loopback,0);
  readonly CancellationTokenSource stop=new();
  readonly bool missingScript;
  readonly Task serve;
  public int Port=>((IPEndPoint)listener.LocalEndpoint).Port;
  public MockGateway(bool missingScript)
  {
   this.missingScript=missingScript;listener.Start();serve=ServeAsync();
  }
  async Task ServeAsync()
  {
   try
   {
    while(!stop.IsCancellationRequested)
    {
     using var client=await listener.AcceptTcpClientAsync(stop.Token);
     var stream=client.GetStream();using var reader=new StreamReader(stream,Encoding.ASCII,leaveOpen:true);
     var first=await reader.ReadLineAsync(stop.Token);if(first==null)continue;
     while(!string.IsNullOrEmpty(await reader.ReadLineAsync(stop.Token))){}
     var path=first.Split(' ').ElementAtOrDefault(1)?.Split('?')[0]??"/";
     var status="200 OK";var type="text/plain";var body="ok";
     if(path=="/healthz"){type="application/json";body="{\"ok\":true}";}
     else if(path=="/"){type="text/html";body="<html><head><link rel=\"stylesheet\" href=\"/assets/ui.css\"></head><body><script type=\"module\" src=\"/assets/ui.js\"></script></body></html>";}
     else if(path=="/assets/ui.js"){type="text/javascript";if(missingScript){status="404 Not Found";body="missing";}else body="document.body.dataset.ready='1';";}
     else if(path=="/assets/ui.css"){type="text/css";body="body{color:#222}";}
     else {status="404 Not Found";body="missing";}
     var bytes=Encoding.UTF8.GetBytes(body);
     var headers=Encoding.ASCII.GetBytes($"HTTP/1.1 {status}\r\nContent-Type: {type}; charset=utf-8\r\nContent-Length: {bytes.Length}\r\nConnection: close\r\n\r\n");
     await stream.WriteAsync(headers,stop.Token);await stream.WriteAsync(bytes,stop.Token);await stream.FlushAsync(stop.Token);
    }
   }
   catch(OperationCanceledException){}
   catch(SocketException) when(stop.IsCancellationRequested){}
   catch(ObjectDisposedException){}
  }
  public async ValueTask DisposeAsync()
  {
   stop.Cancel();listener.Stop();try{await serve.WaitAsync(TimeSpan.FromSeconds(2));}catch(Exception){}stop.Dispose();
  }
 }
}
