---
name: wb-pyinstaller-exe-patch
description: "给已打包的 PyInstaller exe 注入或修改 Python 代码（无源码情况下加功能、改 UI、打补丁）。当用户要求'给某个 .exe 桌宠/工具加功能''改已打包程序的行为''没有源码但要改 exe 里的 Python 逻辑'时使用。核心方法是二进制手术：只替换 PYZ 数据块，逐字节保留 bootloader 与其余元数据。"
user-invocable: true
metadata: { "openclaw": { "emoji": "🩹", "origin": "workbuddy-user" } }
---

# pyinstaller-exe-patch

> 由 WorkBuddy 技能 `pyinstaller-exe-patch` 转换而来，供 OpenClaw 使用。

# PyInstaller exe 打补丁（二进制手术）

给已打包的 PyInstaller exe 加功能，**不要整体重建 CArchive**——那会破坏 bootloader 的 DLL 定位逻辑，必然报
`Failed to load Python DLL pythonXY.dll`。正确做法是二进制手术：复制原 exe 全部字节，只替换 PYZ 数据块，
再精确修正三处元数据。

## 前置：环境必须版本对齐

重打包**必须**用与目标 exe 相同的 Python 主版本（cookie 里的 `pyvers` 字段会告诉你，如 311 = Python 3.11），
否则 PYZ 头的 bytecode magic 不匹配，运行时直接崩。

准备嵌入式解释器 + 对应 PyInstaller：

```bash
# 下载 python-3.11.x-embed-amd64.zip 解压到 py311/，装 pip 后：
py311/python.exe -m pip install pyinstaller==6.22
```

## 步骤 1：探明结构

```python
import struct
data = open("target.exe","rb").read()
idx = data.rfind(b"MEI\x0c\x0b\x0a\x0b\x0e")            # CArchive magic cookie
_, alen, toc_off, toc_len, pyvers, pylib = struct.unpack(
    "!8sIIII64s", data[idx:idx+struct.calcsize("!8sIIII64s")])
ca_start = len(data) - alen                              # bootloader 就是这样算的
```

用 `PyInstaller.archive.readers.CArchiveReader` 拿 PYZ 条目：
`eoff, dlen, ulen, comp, typecode = car.toc["PYZ.pyz"]`，PYZ 绝对偏移 = `ca_start + eoff`。

## 步骤 2：读懂目标代码（Python 3.11+ 别用 pycdc）

`pycdc`/`uncompyle6` 对 3.11+ 控制流支持很差（`MAKE_CELL`/`PUSH_EXC_INFO` 等报 unsupported，
核心方法整段丢失）。**直接用同版本解释器 `dis` 读字节码**更可靠：

```python
import marshal, zlib, dis
toc_offset = struct.unpack_from("!i", pyz_data, 8)[0]
toc_list = marshal.loads(pyz_data[toc_offset:])          # list[(name, (type, off, clen))]
for name, (typ, off, clen) in toc_list:
    if name == "pkg.module":
        co = marshal.loads(zlib.decompress(pyz_data[off:off+clen]))
        dis.dis(co)                                      # 递归 co_consts 可拿到每个方法
```

从字节码里抠出**真实的属性名、方法名、以及属性访问方式**。这一步偷懒会导致补丁运行时抛异常。

> 特别注意：`self.config` 这类对象常是 dataclass/自定义类而非 dict。看清原代码是 `self.config.actions`
> （属性）还是 `self.config["actions"]`（下标）——猜错会 `AttributeError`，且 Tkinter 事件回调里的异常
> 会被静默吞掉，表现为"点了没反应"，极难排查。

## 步骤 3：猴子补丁而非改原模块

改**包入口** `pkg/__init__.py`（它在目标类被使用前执行），用猴子补丁替换方法，其余模块字节级不动：

```python
# pkg/__init__.py —— 保留原有内容后追加
from pkg.pet import DesktopPet
_orig = DesktopPet.show_context_menu

def _patched(self, event):
    ...                      # 复刻原菜单项 + 追加新功能项
DesktopPet.show_context_menu = _patched
```

替换整个方法时，**必须完整复刻原有菜单项/行为**，否则用户会发现原功能消失了。

## 步骤 4：重建 PYZ 并修好 4 个必踩的坑

```python
codes = {nm: zr.extract(nm) for nm in zr.toc}             # 2000+ 模块全取出
codes["pkg"] = compile(open(patched_init, encoding="utf-8").read(), "pkg/__init__.py", "exec")
ZlibArchiveWriter("_np_raw.pyz", entries, code_dict=codes)
```

### 坑 1：ZlibArchiveWriter 丢失包的 type 标志（最隐蔽）

它把所有条目的 type 从 1（package）写成 0（module），运行时报
`No module named 'urllib.parse'; 'urllib' is not a package`。必须从原 PYZ 内部 TOC 恢复：

```python
orig_flags = {e[0]: e[1][0] for e in orig_toc_list}
for i, (nm, (t, off, clen)) in enumerate(new_toc_list):
    if orig_flags.get(nm, t) != t:
        new_toc_list[i] = (nm, (orig_flags[nm], off, clen))
# 重新 marshal 覆盖回去——通常字节数完全相同，可原地覆盖 + 零填充
```

### 坑 2、3：cookie 的 alen 和 toc_off 都要 += delta

PYZ 变大 `delta` 字节后，其后的 TOC/cookie 整体后移，两个字段必须同步更新，
否则分别导致 `decompression resulted in return code -3`（alen 错）和 DLL 找不到（toc_off 错）：

```python
struct.pack_into("!I", out, cookie_new_abs + 8,  alen + delta)      # archive_len
struct.pack_into("!I", out, cookie_new_abs + 12, toc_off + delta)   # toc offset
```

### 坑 4：外层 TOC 条目 `!IIIIBc` 的字段偏移

`+0`=elen, `+4`=**eoff（绝不能动）**, `+8`=dlen, `+12`=ulen, `+16`=comp, `+17`=typecode。
把长度误写到 `+4` 会把 PYZ 的 entry_offset 覆盖掉。改完立刻断言 `eoff` 未变。

### 组装

```python
out = bytearray(len(data) + delta)
out[:pyz_abs]                          = data[:pyz_abs]          # bootloader 原样
out[pyz_abs:pyz_abs+len(new_pyz)]      = new_pyz
out[pyz_abs+len(new_pyz):]             = data[pyz_abs+pyz_dlen:] # TOC+cookie 后移
```

**绝不要**改动 `'s'`(源码) / `'m'`(marshal) 条目的 typecode——bootloader 的 onedir DLL 搜索依赖它。

## 步骤 5：验证（按顺序，逐层排除）

1. `ca_start` 与原 exe 一致；PYZ 偏移处魔数为 `PYZ\0`
2. 手工解析外层 TOC，条目数与原版相同、`eoff` 未变
3. `ZlibArchiveReader` 能读出全部模块，补丁函数名在 code object 里
4. headless 跑几秒：`timeout 6 ./app.exe; echo $?` —— **EXIT=124 是成功**（timeout 杀掉了正常运行的 GUI）；
   有报错则会立刻退出并打印
5. 报错含 `ModuleNotFoundError` 说明结构已 OK、进入 Python 执行阶段了 → 查坑 1

## 步骤 6：收尾自清理（别攒垃圾）

每次运行会产生数十 MB 临时 `.pyz` 和数千个占位文件。在脚本末尾（验证之后）删掉，
否则工作目录几轮就膨胀到几百 MB：

```python
del zr, zv                                   # 释放文件句柄，否则 Windows 删不掉
for t in ("_op.pyz", "_np_raw.pyz", "_np.pyz"):
    try: os.remove(t)
    except OSError: pass
shutil.rmtree("_pph", ignore_errors=True)
```

## 部署

onedir 包只需替换 exe 本身，`_internal/`、assets、config 全部保留原样。
先备份原 exe，再 `cp` 覆盖。改动前后用 `md5sum` 确认部署到位。

## GUI 补丁的性能注意

若功能涉及实时调节（滑块等），**不要在拖动回调里调用重量级的 reload/重新加载资源**——
那会从磁盘重读并重建全部资源，卡到不可用。正确模式：拖动时只做内存级预览
（如 `ImageTk.getimage(photo)` 取回 PIL 原图 → resize → 更新 label + 窗口 geometry），
松手 `<ButtonRelease-1>` 时才落盘并重载一次。同时给面板绑 `WM_DELETE_WINDOW`
恢复被暂停的动画，避免用户点 ✕ 后程序僵住。
