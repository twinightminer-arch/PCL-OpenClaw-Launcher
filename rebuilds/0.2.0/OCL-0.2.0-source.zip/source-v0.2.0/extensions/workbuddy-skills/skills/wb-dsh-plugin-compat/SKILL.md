---
name: wb-dsh-plugin-compat
description: "诊断并修复 DSH Desktop（DeepSeek Harness / dsh-plugin-desktop）第三方插件在版本升级后导致的「恢复模式 / 插件加载失败」问题。当用户反馈 DSH 进恢复模式、plugin tree failed to load、Renderer boot failed for N plugin(s)、failed to import loader entry、cannot get property 'X' without inject，或让你看 DSH 诊断包（diagnostics-*.zip）时使用。"
user-invocable: true
metadata: { "openclaw": { "emoji": "🧯", "origin": "workbuddy-user" } }
---

# dsh-plugin-compat

> 由 WorkBuddy 技能 `dsh-plugin-compat` 转换而来，供 OpenClaw 使用。

# DSH Desktop 插件兼容性排查与修复

DSH Desktop 是 Electron 应用，插件分**两端**：

- **host 端**（`lib/index.js`，跑在 utility process）——报错形如 `plugin tree failed to load: failed to apply loader entry <entry> (<plugin>)`
- **client 端**（`lib/client.js`，跑在渲染进程）——报错形如 `Renderer boot failed for N plugin(s)` / `failed to import loader entry`

profile 插件目录：`C:\Users\<user>\.dsh\profiles\<profile>\node_modules\`
应用资源目录：`<安装目录>\resources\app`（本机为 `E:\DeepSeekHarness\DSH Desktop\resources\app`）

## 第 0 步：先读诊断包（别猜）

恢复模式里的「导出诊断」生成：
`%APPDATA%\DSH Desktop\diagnostics\diagnostics-<runId>-<uuid>.zip`

包内：

| 文件 | 用途 |
|---|---|
| `lifecycle-events/summary.json` | **最快定位**：`finalStage` / `rendererStatus` / `stages[].status` |
| `lifecycle-events/startup.jsonl` | `renderer.boot.failed` 的 `details.pluginIds` → 点名的插件 |
| `crash-evidence/active-run.json` | 当前 run 的 pid / version |
| `dsh-<date>.log` / `.error.log` | 详情。**注意：跨次启动累积**，必须按 `run <id>` 分段只看最新那段 |

判读要点：
- `host-boot` completed 而 `renderer-startup` failed → 问题在 client 端。
- 报错**没有 message**（`The client Loader did not provide an error message`）**不等于没错误**，
  加载器把单插件异常吞了。见下面「三类根因」的第 1 类。

## 三类根因（按出现频率）

### 1. inject 里声明了「不存在的服务」→ fiber 永久 pending

症状：`Renderer boot failed for N plugin(s)`，`report.error` 为空。

cordis 的 `inject: ["X"]` 是在**等待**服务 X 就绪；X 若从未被提供，fiber 永远进不了 ACTIVE，
`apply()` 永不执行，且因为是「等待」不是「抛错」，加载器给不出 message。

**定位**：把该插件 `inject` 数组里每一项拿去 app 全量 grep，零命中的就是元凶
（实例：`dsh-file-mentions` 声明了 `conversationEvents`，2.0.13 全 app 零命中）。

**修法**：从 inject 移除该项，并把 `ctx.get("X")` 包进 try/catch 降级。**不要反过来补 inject。**

### 2. require 了「已被移除的平台模块」

症状：`failed to import loader entry <hash> (<plugin>): client-modules: require("<mod>") missed the
module table – not a platform seed word, not a materialized module, and no registered package factory`。

**平台模块白名单的权威判据**：`resources\app\package.json` 的 `dependencies` 里列出的
`@deepseek-ai/dsh-client-*` 就是渲染端模块表成员。

已确认的迁移（2.0.13）：
- ❌ `@deepseek-ai/dsh-client-runtime/client` → ✅ `@deepseek-ai/dsh-client-store`
  （同名导出 `createSnapshotStore(init, opts)`、`defineStore(decl)`，`decl = {init, persist, actions}`）
- `@deepseek-ai/dsh-client-ui-primitives`、`@deepseek-ai/dsh-client-store` 在表内，可放心 require

**修法**：改 require 的目标包名即可（变量名不必改）。

### 3. `ctx.<prop>` 属性访问了「未声明且不可用」的服务

症状：`plugin tree failed to load: ... cannot get property "X" without inject`。

**修法二选一**：
- 该服务确实需要 → 在 inject 里补声明；
- 服务在**当前这一端**根本不存在（如 client 端去访问 host-only 服务）→ 改为 `ctx.get("X")` + try/catch。

**⚠️ 语义对照表（几次误诊都源于没搞清这个）**：

| 写法 | 服务不存在时 |
|---|---|
| `ctx.get("X")` 方法调用 | 返回 `undefined`，**不抛错** |
| `ctx.X` 属性访问 | 未声明且**在其 ctx 树中不可用** → 抛 `without inject` |
| `inject: ["X"]` 声明 | **永久 pending**，apply 不执行，报错无 message |

注意第 3 类只在「该服务在插件自己的 ctx 树里也拿不到」时才致命。若服务由祖先插件提供、
只是没写进 `inject`，属性访问照样正常——所以扫描器把第 3 类标为**弱信号**，必须结合报错确认。
**真正高置信度的只有第 1 类和第 2 类。**

### 4. 插件劫持了核心 API 但签名过期（界面静默空白，不进恢复模式）

症状：**不报任何崩溃**，DSH 能起来，但主对话区（main 槽位）整片空白，侧栏/右栏有内容；
渲染端 console 反复报 `TypeError: <x> is not iterable` / `cannot read properties of undefined`。

机理：某插件用 `locale.lookup = function(ns, key){...}` 之类**整体覆盖**了官方核心方法，
但官方升级后该方法的**形参列表变了**（典型：2.0.13 给 `lookup(ns, key, chain)` 加了第三参 `chain`，
内部 `for (const locale of chain)`）。插件旧签名漏掉新参 → 调用方传进来的 `chain` 落在 `undefined` → 抛错 →
每个槽位被 React 错误边界接管 → 整页空白。

**定位**：渲染端 console / 错误边界里抓到 `is not iterable` 之类 TypeError 后，
对 `locale.lookup =` / `locale.translate =` / `Object.defineProperty(locale,...)` / `locale.prototype` 在
profile `node_modules` 里全量 grep（本机实例：`deepseek-harness-zh_pro` 汉化包在 `lib/client.js:912`
把 `lookup` 写成 `function(ns, key)` 漏了 `chain`）。

**修法**：把被覆盖方法的签名对齐到官方当前版本（读 `resources/app/node_modules/@deepseek-ai/dsh-client-locale/lib/client.js`
里 `lookup`/`translate` 的真实签名），新参透传给 `originalXxx.call(this, ...args)`。
覆盖函数内部若调用原方法，也必须把新参一并传下去（不止一处调用点）。

**辅助手段**：在 `resources/app/lib/client.js` 顶部注入诊断探针（先备份为 `client.js.bak-diag`），
抓 `window.error` / `unhandledrejection` / `console.error` 写进黄色横幅，**无错即隐藏**；
本机沙箱起不来 GUI，需用户双击启动后看横幅/窗口标题回传。验证通过后再用 bak 还原官方文件。

## 排查脚本

```bash
# 三类问题一次扫完（require 白名单 / inject 幽灵服务 / ctx 属性访问）
python scripts/scan_plugin_compat.py
```

脚本自动定位 profile 与 app 目录，输出可疑插件清单。

## 验证（必做，比 node --check 有效得多）

```bash
# 模拟渲染端 shell 实跑 factory，检查依赖是否白名单 + factory 是否抛错
node scripts/sim_load_client.mjs "<插件>/lib/client.js" [...]
```

原理：`runInNewContext` 注入 `window.__ModuleLoader__.load` 捕获 registration，用假 require
（配 document / MutationObserver / NodeFilter / requestAnimationFrame stub）实跑 `factory()`。

## 环境坑（本机实测）

- **PowerShell 工具的输出通道常不回显** → 结果一律写日志文件，再用 Read 读。
- `New-Object -ComObject` 被安全策略拦截 → 改写 `.py` 走 `win32com`。
- 需要 Pillow + pywin32 的 venv：`C:\Users\<user>\.workbuddy\binaries\python\envs\default\Scripts\python.exe`
- **Edit 工具偶发不生效**（返回成功但内容未变）→ 关键改动后用 Python 精确 replace 写回，并 **Read 回读复核**。

## 持久性提醒（务必告诉用户）

所有修复都落在 `node_modules` / app 安装目录：

- app 更新或重装 → app 侧补丁（如 `dsh-client-connection` 的 webServer 守卫）被覆盖；
- `dsh plugin add` / 重装插件 → profile 侧补丁被覆盖。

根治要向上游提 issue。重启验证前，先把改动点记进当天 memory。
