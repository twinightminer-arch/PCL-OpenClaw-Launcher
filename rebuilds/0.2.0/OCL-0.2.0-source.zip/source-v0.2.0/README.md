# OCL 0.2.0 重制版

这是 Windows WPF 版 OpenClaw Launcher 的独立重制副本。它保留实例、配置、插件、Wallpaper Engine、连接状态、版本管理和个性化等现有能力，并修正启动时隐式运行网关、把 TCP 误当 HTTP 健康、控制台静态资源未验证及启动动画未收起的问题。

## 行为约定

- 打开启动器只呈现界面和本地快照，不运行 OpenClaw CLI，也不启动网关。
- “启动实例”是启动网关的唯一直接入口；“打开控制台”先检查健康状态，未就绪时需要用户再次确认。
- 成功状态按进程、TCP、HTTP `/healthz`、控制台 HTML/同源资源和 WebSocket challenge 分阶段记录。
- 外部浏览器的认证后 RPC 状态无法由启动器直接观察，界面会明确标为待浏览器确认，不会声称 RPC 已就绪。
- 日志与诊断不记录控制台 URL、token 或 WebSocket challenge 内容。

## 构建

运行本目录中的 `build.ps1`。构建输出在同级 `app-v0.2.0`，为 Windows x64 框架依赖 .NET GUI 目录（运行需要 .NET 10 Desktop Runtime）。先完成产物验证，再更新桌面快捷方式。

源码比较与版本取舍见 [SOURCE-COMPARISON.md](SOURCE-COMPARISON.md)。

