using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ClawLauncher;

public sealed record InstanceDeletionPlan(
 string InstanceId,
 string StateRoot,
 IReadOnlyList<string> PreservePaths,
 IReadOnlyList<string> RemovePaths,
 IReadOnlyList<string> BlockedPaths)
{
 public bool SafeToDelete => BlockedPaths.Count == 0;
}

/// <summary>Builds a fail-closed inventory for deleting an OCL-managed instance.</summary>
public static class InstanceDeletion
{
 static readonly HashSet<string> UserDataRoots = new(StringComparer.OrdinalIgnoreCase)
  { "workspace", "memory", "media", "uploads", "credentials" };
 static readonly HashSet<string> RemovableRoots = new(StringComparer.OrdinalIgnoreCase)
  { "extensions", "plugins", "plugin-skills", "skills", "cache", "logs", "npm", "bin", "state", "browser", "canvas", "openclaw-weixin", "qqbot" };
 static readonly HashSet<string> CredentialFiles = new(StringComparer.OrdinalIgnoreCase)
  { "auth-profiles.json", "auth.json", "device-auth.json", "models.json" };

 public static InstanceDeletionPlan Plan(string launcherDataRoot, Instance instance)
 {
  var root = Path.GetFullPath(launcherDataRoot);
  var expected = Path.GetFullPath(Path.Combine(root, "instances", instance.Id));
  var state = Path.GetFullPath(instance.State);
  var preserve = new List<string>();
  var remove = new List<string>();
  var blocked = new List<string>();
  if (!instance.Managed || !SamePath(state, expected))
   return new(instance.Id, state, preserve, remove, [state + "（不是 OCL 专属实例目录）"]);
  if (!Directory.Exists(state)) return new(instance.Id, state, preserve, remove, blocked);
  if (HasReparsePoint(state))
   return new(instance.Id, state, preserve, remove, [state + "（包含目录联接或符号链接）"]);
  if (instance.Config.Length > 0 && !IsUnder(state, Path.GetFullPath(instance.Config)))
   blocked.Add(Path.GetFullPath(instance.Config) + "（配置位于实例目录之外）");

  foreach (var path in Directory.EnumerateFileSystemEntries(state))
  {
   var name = Path.GetFileName(path);
   if (HasReparsePoint(path)) { blocked.Add(path + "（目录联接或符号链接）"); continue; }
   if (UserDataRoots.Contains(name)) { preserve.Add(path); continue; }
   if (name.Equals("agents", StringComparison.OrdinalIgnoreCase))
   {
    InspectAgents(path, preserve, remove, blocked);
    continue;
   }
   if (name.Equals("openclaw.json", StringComparison.OrdinalIgnoreCase) ||
       name.StartsWith("openclaw.json.", StringComparison.OrdinalIgnoreCase) ||
       RemovableRoots.Contains(name)) {
    if (Directory.Exists(path)) FindReparsePoints(path, blocked);
    remove.Add(path); continue;
   }
   blocked.Add(path + "（未分类；为保护数据已停止删除）");
  }
  return new(instance.Id, state, preserve, remove, blocked);
 }

 static void InspectAgents(string agentsRoot, List<string> preserve, List<string> remove, List<string> blocked)
 {
  var pending = new Stack<string>(); pending.Push(agentsRoot);
  while (pending.Count > 0)
  {
   var dir = pending.Pop();
   foreach (var path in Directory.EnumerateFileSystemEntries(dir))
   {
    if (HasReparsePoint(path)) { blocked.Add(path + "（目录联接或符号链接）"); continue; }
    if (Directory.Exists(path))
    {
     if (Path.GetFileName(path).Equals("sessions", StringComparison.OrdinalIgnoreCase)) preserve.Add(path);
     else pending.Push(path);
     continue;
    }
    if (CredentialFiles.Contains(Path.GetFileName(path))) preserve.Add(path);
    else blocked.Add(path + "（agent 数据无法安全分类）");
   }
  }
 }

 static void FindReparsePoints(string root, List<string> blocked)
 {
  var pending = new Stack<string>(); pending.Push(root);
  while (pending.Count > 0)
  {
   foreach (var path in Directory.EnumerateFileSystemEntries(pending.Pop()))
   {
    if (HasReparsePoint(path)) { blocked.Add(path + "（目录联接或符号链接）"); continue; }
    if (Directory.Exists(path)) pending.Push(path);
   }
  }
 }

 public static string DeleteManagedState(string launcherDataRoot, Instance instance)
 {
  var plan = Plan(launcherDataRoot, instance);
  if (!plan.SafeToDelete) throw new InvalidOperationException("实例目录含有无法安全分类的数据，已取消删除：" + string.Join("；", plan.BlockedPaths));
  var archive = Path.Combine(Path.GetFullPath(launcherDataRoot), "preserved-user-data", instance.Id + "-" + DateTime.UtcNow.ToString("yyyyMMddTHHmmssfffZ"));
  if (plan.PreservePaths.Count > 0)
  {
   Directory.CreateDirectory(archive);
   foreach (var source in plan.PreservePaths)
   {
    var relative = Path.GetRelativePath(plan.StateRoot, source);
    var destination = Path.Combine(archive, relative);
    Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
    if (Directory.Exists(source)) Directory.Move(source, destination);
    else File.Move(source, destination);
   }
   File.WriteAllLines(Path.Combine(archive, "preserved-paths.txt"), plan.PreservePaths.Select(p => Path.GetRelativePath(plan.StateRoot, p)));
  }
  // Re-scan after moving user data so a file created during confirmation cannot
  // be swept up by a broad recursive delete.
  var remaining = Plan(launcherDataRoot, instance);
  if (!remaining.SafeToDelete) throw new InvalidOperationException("删除期间实例目录出现了未分类数据，已停止清理：" + string.Join("；", remaining.BlockedPaths));
  foreach (var path in remaining.RemovePaths)
  {
   if (Directory.Exists(path)) Directory.Delete(path, recursive: true);
   else if (File.Exists(path)) File.Delete(path);
  }
  RemoveEmptyDirectories(plan.StateRoot);
  if (Directory.Exists(plan.StateRoot) && !Directory.EnumerateFileSystemEntries(plan.StateRoot).Any()) Directory.Delete(plan.StateRoot, recursive: false);
  if (Directory.Exists(plan.StateRoot)) throw new IOException("实例目录仍包含文件，未从 OCL 列表移除：" + plan.StateRoot);
  return plan.PreservePaths.Count > 0 ? archive : "";
 }

 static void RemoveEmptyDirectories(string root)
 {
  if (!Directory.Exists(root)) return;
  foreach (var dir in Directory.EnumerateDirectories(root, "*", SearchOption.AllDirectories).OrderByDescending(p => p.Length))
   if (Directory.Exists(dir) && !Directory.EnumerateFileSystemEntries(dir).Any()) Directory.Delete(dir, recursive: false);
 }

 static bool SamePath(string left, string right) => string.Equals(
  Path.TrimEndingDirectorySeparator(Path.GetFullPath(left)),
  Path.TrimEndingDirectorySeparator(Path.GetFullPath(right)), StringComparison.OrdinalIgnoreCase);

 static bool IsUnder(string root, string path) => path.StartsWith(
  Path.TrimEndingDirectorySeparator(Path.GetFullPath(root)) + Path.DirectorySeparatorChar,
  StringComparison.OrdinalIgnoreCase);

 static bool HasReparsePoint(string path)
 {
  try { return (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0; }
  catch (FileNotFoundException) { return false; }
  catch (DirectoryNotFoundException) { return false; }
 }
}
