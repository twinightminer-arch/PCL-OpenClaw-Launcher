# WorkBuddy Skills for OpenClaw

把 WorkBuddy 的 7 个用户级技能 + 27 个内置技能转换成 OpenClaw 技能。
统一加 `wb-` 前缀，避免与 OpenClaw 自带技能同名。

共 34 个：

- `wb-ardot-design-core`（源：`ardot-design-core`）
- `wb-ardot-design-to-code`（源：`ardot-design-to-code`）
- `wb-ardot-poster`（源：`ardot-poster`）
- `wb-ardot-slides`（源：`ardot-slides`）
- `wb-ardot-ui-design`（源：`ardot-ui-design`）
- `wb-buddy-image-processing`（源：`buddy-image-processing`）
- `wb-buddy-multimodal-generation`（源：`buddy-multimodal-generation`）
- `wb-cloud-service`（源：`cloud-service`）
- `wb-design-router`（源：`design-router`）
- `wb-dsh-plugin-compat`（源：`dsh-plugin-compat`）
- `wb-expert-manager`（源：`expert-manager`）
- `wb-geo-map-compliance-guard`（源：`geo-map-compliance-guard`）
- `wb-library`（源：`library`）
- `wb-livestream-poster`（源：`livestream-poster`）
- `wb-marketplace-skill-installer`（源：`marketplace-skill-installer`）
- `wb-miora-brand-design`（源：`miora-brand-design`）
- `wb-miora-creative-core`（源：`miora-creative-core`）
- `wb-miora-image-generation`（源：`miora-image-generation`）
- `wb-miora-video-generation`（源：`miora-video-generation`）
- `wb-obsidian`（源：`obsidian`）
- `wb-openclaw-plugin-authoring`（源：`openclaw-plugin-authoring`）
- `wb-pyinstaller-exe-patch`（源：`pyinstaller-exe-patch`）
- `wb-recommend-connectors`（源：`recommend-connectors`）
- `wb-recommend-experts`（源：`recommend-experts`）
- `wb-sites`（源：`sites`）
- `wb-skill-creator`（源：`skill-creator`）
- `wb-software-version-update`（源：`software-version-update`）
- `wb-tencent-docs-routing`（源：`tencent-docs-routing`）
- `wb-tencent-local-office-edit`（源：`tencent-local-office-edit`）
- `wb-wb-finance-skill`（源：`wb-finance-skill`）
- `wb-wecom-forwarded-chat-resources`（源：`wecom-forwarded-chat-resources`）
- `wb-windows-shortcut-icon`（源：`windows-shortcut-icon`）
- `wb-word-template-fill`（源：`word-template-fill`）
- `wb-workbuddy-smartsheet`（源：`workbuddy-smartsheet`）

安装（--link 保持在 E 盘，不复制到 C 盘）：

```bash
node openclaw.mjs plugins install E:\openclaw\ocl\extensions\workbuddy-skills --link --force
```