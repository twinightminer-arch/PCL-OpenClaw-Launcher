# -*- coding: utf-8 -*-
"""
set_shortcut_icon.py —— Windows 下把任意图片设为 .lnk 快捷方式图标

用法:
    python set_shortcut_icon.py <图片路径> <快捷方式.lnk 路径> [--label deepseek] [--ico-out 目录]

做三件事:
  1. 图片 -> 多尺寸透明 ICO（白底自动扣掉，边缘抗锯齿反白）
  2. ICO 写入 .lnk 的 IconLocation
  3. 刷新 shell 图标缓存

依赖: Pillow, pywin32  (win32com)
注意: 必须在【脚本文件】里跑，不要在 PowerShell 单行命令里用 New-Object -ComObject，
      沙箱策略会拦 COM 实例化。
"""
import os
import sys
import io
import struct
import argparse
import hashlib
import subprocess
from collections import deque

from PIL import Image

SIZES = [16, 20, 24, 32, 40, 48, 64, 96, 128, 256]

# 若原图是「深色主体 + 纯白底」，用主体主色做反白解算；自动从图中取主色
def _dominant_color(im):
    """取非白像素的【众数】作为主体色。

    不能用均值：抗锯齿边缘是白+主色的渐变，混进均值会把主色拉浅，
    导致反白环带染上偏浅的颜色。按 8 级量化后取出现次数最多的色。
    """
    px = im.load()
    w, h = im.size
    counts = {}
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a < 12:
                continue
            if r > 240 and g > 240 and b > 240:
                continue
            key = (r >> 3, g >> 3, b >> 3)
            e = counts.get(key)
            if e is None:
                counts[key] = [1, r, g, b]
            else:
                e[0] += 1; e[1] += r; e[2] += g; e[3] += b
    if not counts:
        return (0, 0, 0)
    key = max(counts, key=lambda k: counts[k][0])
    c = counts[key]
    return (c[1] // c[0], c[2] // c[0], c[3] // c[0])


def strip_white_bg(img, white_th=240, ring_iter=2):
    """把与边框连通的纯白背景置为透明，并把边缘抗锯齿像素反白成半透明主体色"""
    im = img.convert('RGBA')
    w, h = im.size
    px = im.load()
    fg = _dominant_color(im)

    bg = bytearray(w * h)
    dq = deque()

    def white(x, y):
        r, g, b, a = px[x, y]
        return r >= white_th and g >= white_th and b >= white_th and a > 0

    for x in range(w):
        for y in (0, h - 1):
            if not bg[y * w + x] and white(x, y):
                bg[y * w + x] = 1
                dq.append((x, y))
    for y in range(h):
        for x in (0, w - 1):
            if not bg[y * w + x] and white(x, y):
                bg[y * w + x] = 1
                dq.append((x, y))
    while dq:
        x, y = dq.popleft()
        for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
            if 0 <= nx < w and 0 <= ny < h and not bg[ny * w + nx] and white(nx, ny):
                bg[ny * w + nx] = 1
                dq.append((nx, ny))

    # 与背景相邻的环带 -> 按亮度反推 alpha，颜色统一成主体色
    ring = bytearray(w * h)
    frontier = [(x, y) for y in range(h) for x in range(w) if bg[y * w + x]]
    for _ in range(ring_iter):
        nf = []
        for x, y in frontier:
            for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                if 0 <= nx < w and 0 <= ny < h and not bg[ny * w + nx] and not ring[ny * w + nx]:
                    ring[ny * w + nx] = 1
                    nf.append((nx, ny))
        frontier = nf

    denom = max(1, 255 - fg[0])
    for y in range(h):
        for x in range(w):
            i = y * w + x
            if bg[i]:
                px[x, y] = (0, 0, 0, 0)
            elif ring[i]:
                r = px[x, y][0]
                est = (255.0 - r) / denom
                est = 0.0 if est < 0 else (1.0 if est > 1 else est)
                if est < 0.12:
                    px[x, y] = (0, 0, 0, 0)
                else:
                    px[x, y] = (fg[0], fg[1], fg[2], int(round(est * 255)))
    return im.crop(im.getbbox())


def split_icon_and_text(im, scan_from=0.35, min_gap=3):
    """在图像下半部找最长的水平空白带，把「图标主体」和「下方文字」分开。
    返回主体部分（找不到空白带就返回整图）。"""
    w, h = im.size
    a = im.split()[3].load()
    rows = []
    for y in range(h):
        c = 0
        for x in range(w):
            if a[x, y] > 24:
                c += 1
        rows.append(c)
    cur = 0
    start = None
    bstart = blen = None
    for y in range(int(h * scan_from), h):
        if rows[y] == 0:
            if cur == 0:
                start = y
            cur += 1
            if blen is None or cur > blen:
                blen, bstart = cur, start
        else:
            cur = 0
    if bstart is None or blen < min_gap:
        return im
    top = im.crop((0, 0, w, bstart))
    return top.crop(top.getbbox()) if top.getbbox() else im


def fit_square(im, size, pad_ratio=0.05):
    w, h = im.size
    inner = int(size * (1 - 2 * pad_ratio))
    sc = min(inner / w, inner / h)
    nw, nh = max(1, int(round(w * sc))), max(1, int(round(h * sc)))
    rs = im.resize((nw, nh), Image.LANCZOS)
    cv = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    cv.paste(rs, ((size - nw) // 2, (size - nh) // 2), rs)
    return cv


def write_ico(frames, path):
    """frames: [(size, RGBA)] -> 手写 ICO（PNG 编码，支持逐尺寸不同源图）"""
    frames = sorted(frames, key=lambda t: t[0])
    blobs = []
    for _, f in frames:
        buf = io.BytesIO()
        f.save(buf, format='PNG', optimize=True)
        blobs.append(buf.getvalue())
    n = len(frames)
    header = struct.pack('<HHH', 0, 1, n)
    offset = 6 + 16 * n
    entries = b''
    data = b''
    for (sz, _), blob in zip(frames, blobs):
        dim = 0 if sz >= 256 else sz
        entries += struct.pack('<BBBBHHII', dim, dim, 0, 0, 1, 32, len(blob), offset)
        data += blob
        offset += len(blob)
    with open(path, 'wb') as fp:
        fp.write(header + entries + data)
    return os.path.getsize(path)


def build_ico(src_image, ico_path, small_max=48, small_uses_body=True):
    """生成 ICO。small_max 及以下用「主体部分」，更大的尺寸用完整图（含文字）。"""
    im = Image.open(src_image)
    master = strip_white_bg(im)
    body = split_icon_and_text(master) if small_uses_body else master
    frames = []
    for s in SIZES:
        if s <= small_max and body is not master:
            frames.append((s, fit_square(body, s, 0.055)))
        else:
            frames.append((s, fit_square(master, s, 0.045)))
    return write_ico(frames, ico_path)


def verify_ico(path):
    raw = open(path, 'rb').read()
    _, typ, cnt = struct.unpack('<HHH', raw[:6])
    assert typ == 1, 'not an icon'
    info = []
    for i in range(cnt):
        off = 6 + 16 * i
        bw, bh, _c, _r, _p, _bpp, bsize, boff = struct.unpack('<BBBBHHII', raw[off:off + 16])
        blob = raw[boff:boff + bsize]
        dw = 256 if bw == 0 else bw
        if blob[:8] == b'\x89PNG\r\n\x1a\n':
            pw, ph = struct.unpack('>II', blob[16:24])
            assert (pw, ph) == (dw, dw), 'frame %d mismatch' % i
            kind = 'PNG'
        else:
            kind = 'BMP'
        info.append('%dx%d:%s:%dB' % (dw, dw, kind, bsize))
    return cnt, info


def set_lnk_icon(lnk_path, ico_path):
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    sh = win32com.client.Dispatch('WScript.Shell')
    lnk = sh.CreateShortcut(lnk_path)
    before = lnk.IconLocation
    lnk.IconLocation = ico_path + ',0'
    lnk.Save()
    return before, lnk.IconLocation


def refresh_shell():
    import ctypes
    try:
        subprocess.run(['ie4uinit.exe', '-show'], capture_output=True, timeout=30)
    except Exception:
        pass
    try:
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0x0000, None, None)
    except Exception:
        pass


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('image')
    ap.add_argument('lnk')
    ap.add_argument('--ico-out', default=os.path.join(
        os.environ.get('LOCALAPPDATA', os.path.expanduser('~')), 'WorkBuddyIcons'))
    ap.add_argument('--name', default=None, help='ICO 文件名（不含扩展名），默认取 lnk 名')
    ap.add_argument('--no-crop-body', action='store_true', help='小尺寸也用完整图，不做主体裁剪')
    a = ap.parse_args()

    os.makedirs(a.ico_out, exist_ok=True)
    name = a.name or os.path.splitext(os.path.basename(a.lnk))[0]
    ico = os.path.join(a.ico_out, name + '.ico')

    src = Image.open(a.image)
    fg = _dominant_color(strip_white_bg(src))
    print('主体主色 = #%02X%02X%02X' % fg)

    size = build_ico(a.image, ico, small_uses_body=not a.no_crop_body)
    cnt, info = verify_ico(ico)
    print('ICO: %s' % ico)
    print('  %d frames, %d bytes' % (cnt, size))
    for x in info:
        print('   ', x)

    # 抽样确认：边框应透明、主体区应是主色
    chk = Image.open(ico).convert('RGBA')
    cpx = chk.load()
    cw, ch = chk.size
    print('  四角 alpha =', [cpx[0, 0][3], cpx[cw - 1, 0][3], cpx[0, ch - 1][3], cpx[cw - 1, ch - 1][3]])

    before, after = set_lnk_icon(a.lnk, ico)
    print('LNK: %s' % a.lnk)
    print('  before: %s' % before)
    print('  after : %s' % after)
    print('  md5   : %s' % hashlib.md5(open(ico, 'rb').read()).hexdigest())
    refresh_shell()
    print('OK - shell icon cache refreshed (desktop may need F5)')


if __name__ == '__main__':
    main()
