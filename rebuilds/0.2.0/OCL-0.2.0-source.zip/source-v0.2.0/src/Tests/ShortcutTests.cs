using ClawLauncher;
using System.Runtime.Versioning;

internal static class ShortcutTests
{
 [SupportedOSPlatform("windows")]
 public static (bool Ok, string Name) PreserveCustomIcon()
 {
  var root=Path.Combine(Path.GetTempPath(),"ocl-shortcut-test-"+Guid.NewGuid().ToString("N"));
  Directory.CreateDirectory(root);
  try
  {
   var link=Path.Combine(root,"OCL.lnk");
   var expected=Path.Combine(Environment.SystemDirectory,"shell32.dll")+",15";
   var shellType=Type.GetTypeFromProgID("WScript.Shell")??throw new InvalidOperationException("Windows Script Host COM is unavailable.");
   dynamic shell=Activator.CreateInstance(shellType)!;
   dynamic shortcut=shell.CreateShortcut(link);
   shortcut.TargetPath=Environment.ProcessPath??throw new InvalidOperationException("Test process path is unavailable.");
   shortcut.WorkingDirectory=root;
   shortcut.IconLocation=expected;
   shortcut.Save();

   new Store(Path.Combine(root,"data")).WriteShortcut(link,preserveExistingIcon:true);
   dynamic updated=shell.CreateShortcut(link);
   var actual=(string)updated.IconLocation;
   var ok=string.Equals(expected,actual,StringComparison.OrdinalIgnoreCase)&&File.Exists((string)updated.TargetPath);
   return (ok,"shortcut target update preserves a user's custom icon");
  }
  finally { try { Directory.Delete(root,true); } catch(IOException) { } }
 }
}
